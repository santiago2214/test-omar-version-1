<?php 
include"header.php";
include "../connection.php";

$id=$_GET["id"];
$exam_categoory='';
$res=mysqli_query($link,"select * from exam_category where id=$id ");
while($row=mysqli_fetch_array($res))
{
    $exam_category=$row["category"];
}

 ?>


        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Agregar Pregunta dentro <?php echo "<font color='red'>" .$exam_category. "</font>"; ?> </h1>
                    </div>
                </div>
            </div>
           
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">


                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                           
                            <div class="card-body">
                                

                                 <div class="col-lg-9">
                                    <form name="form1" action="" method="POST">
                        <div class="card">
                            <div class="card-header"><strong>Agregar Nueva Pregunta </strong></div>
                            <div class="card-body card-block">

                                <div class="form-group"><label for="company" class=" form-control-label"> Pregunta</label><input type="text" name="question" placeholder="Agregue la pregunta" class="form-control" ></div>
                                   
                                   <div class="form-group"><label for="company" class=" form-control-label"> Opción 1</label><input type="text" name="opt1" placeholder="Agregue la opción" class="form-control" ></div>

                                   <div class="form-group"><label for="company" class=" form-control-label"> Opción 2</label><input type="text" name="opt2" placeholder="Agregue la opción" class="form-control" ></div>

                                   <div class="form-group"><label for="company" class=" form-control-label"> Opción 3</label><input type="text" name="opt3" placeholder="Agregue la opción" class="form-control" ></div>

                                   <div class="form-group"><label for="company" class=" form-control-label"> Opción 4</label><input type="text" name="opt4" placeholder="Agregue la opción" class="form-control" ></div>

                                   <div class="form-group"><label for="company" class=" form-control-label"> Respuesta correcta</label><input type="text" name="answer" placeholder="Agregue la respuesta correcta" class="form-control" ></div>



                                        <div class="form-group">
                                            <input type="submit" name="submit1" value="Agregar pregunta" class="btn btn-success ">
                                        </div>
                                        
                                    </div>
                                </div>
                            </form>
                                
                            </div>


                        </div> 
                            </div>
                        </div> 

                    </div>
                    <!--/.col-->


                                        </div><!-- .animated -->
                                    </div><!-- .content -->


<?php 
if (isset($_POST["submit1"])) {
    $loop=0;

    $count=0;

    $res=mysqli_query($link,"select * from questions where category='$exam_category' order by id asc") or die(mysqli_error($link));
    $coutn=mysqli_num_rows($res);
    if ($count==0) {
        
    }else{
        while($row=mysqli_fetch_array($res))
        {
            $loop=$loop+1;

            mysqli_query($link,"update questions set question_no='$loop' where id=$row[id]");
        }
    }

    $loop=$loop+1;

    mysqli_query($link,"insert into questions values(NULL,'$loop','$_POST[question]','$_POST[opt1]','$_POST[opt2]','$_POST[opt3]','$_POST[opt4]','$_POST[answer]','$exam_category')") or die (mysqli_error($link));
 ?>

<script type="text/javascript">
    alert("Pregunta agregada correctamente");
    window.location.href=window.location.href;

</script>
<?php 
}


                               


<?php 

include "footer.php ";


?>